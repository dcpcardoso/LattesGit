package leitor;

import Bezerra.*;
import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class JAXBExample {

    public static void main(String[] args) {

        try {

            File file = new File("C:\\Users\\Daniel\\Downloads\\7568520840965379\\curriculo.xml");
            JAXBContext jaxbContext = JAXBContext.newInstance(CURRICULOVITAEType.class);

            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            CURRICULOVITAEType customer = (CURRICULOVITAEType) jaxbUnmarshaller.unmarshal(file);
            System.out.println(customer);

        } catch (JAXBException e) {
            e.printStackTrace();
        }

    }
}
